import 'package:flutter/material.dart';

void main(){
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget buid(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: const Text("I Am Football Player"),
          backgroundColor: Colors.grey,
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/siuu.jpg', width: 1000),
              const SizedBox(height: 50)
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "One celebration, millions of fans screaming SIIUUU! ⚡",
                      style: TextStyle(fontSize: 15),
                      textAlign: TextAlign.left,
                    ),
                    SizedBox(height: 5,),
                    Text(
                      "Gol cantik tidak perlu, selebrasi nomor satu :)",
                      style: TextStyle(fontSize: 15),
                      textAlign: TextAlign.left,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    ),
  }
}